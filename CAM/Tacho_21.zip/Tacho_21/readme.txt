
Axilator
Bengt Palmkvist
G:a Grycksbov. 31
791 38 FALUN
SWEDEN

tel: +46 23 23656
email: bengt.palmkvist@axilator.se

__________________________________________________________

PCB specifications:
__________________________________________________________

Name:  		TACHO V.2.0
                                 
Card:         	Circular 46 mm

Layers:		2

Material:	Standard (FR-4)

Laminate:	Standard (1,6 mm)

Copper:	Standard (35 um)

Surface:	Standard (Hot-air levelling)


Min. track width:	6 mil (0,15mm)
Min. clearance:		6 mil (0.15mm)
Min. via diameter:	0,8mm
Min. via drill:		0,4mm


Silkscreen at both layers

__________________________________________________________

File specifications:
__________________________________________________________
Photoplotter GERBER RS-274-X
Data unit: inch
0 mil X and Y offset.

File:			Type:
TopCu.GTL		Top, layer
BotCu.GBL		Bot, layer
MaskTop.GTS	neg	Solder Mask Top
MaskBot.GBS	neg	Solder Mask Bottom
Board.GML		Board contour
SilkTop.GTO		Silkscreen top
SilkBot.GBO		Silkscreen bot

Drill.TXT		Drill, Excellon
Drill.rep		Drill size




